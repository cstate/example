---
title:
date:
resolved:
resolvedWhen:
# You can use: down, disrupted, notice
severity:
affected:
section: issue
---
