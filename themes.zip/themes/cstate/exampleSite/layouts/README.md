This folder can be used to overwrite or add any layouts to your status page.

For more, please [read the documentation](https://github.com/cstate/cstate/wiki/Customization).
