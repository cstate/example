This is the default cState status page website directory/folder.

https://github.com/cstate/example
