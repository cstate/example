---
title: Maintenance Window
date: 2018-06-13 15:54:00
resolved: true
resolvedWhen: 2018-06-13 16:54:00
# Possible severity levels: down, disrupted, notice
severity: disrupted
affected:
  - API
section: issue
---

*Just began* - We're currently shutting down the network. {{< track "2018-06-13 15:54:00" >}}
