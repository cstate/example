---
title: New Pipeline Rollout
date: 2019-10-05 16:24:00
resolved: false
resolvedWhen: 2019-10-05 16:58:00
# Possible severity levels: down, disrupted, notice
severity: disrupted
affected:
  - API
section: issue
---

There may be disruptions in the rollout.