---
title: Testing New cState Features
date: 2019-10-04 18:05:00
informational: true
section: issue
---

There is a new feature in cState version 4 that lets you make what are called _informational_ posts. The main difference is that there will be no _Unresolved_ or _Resolved in under a minute_ text on the pages.

This is essentially a page with a date and title.